### Expected Behavior :



### Actual Behavior :



### Steps to Reproduce :



##### Additional Information :


###### Device, Kodi Version, Lastship Version :

###### Environment (Hardware, OS, ...) :

###### Network Setup :

###### **Link to** [**Debug-Logfile**](http://kodi.wiki/view/Log_file) :


- - -
