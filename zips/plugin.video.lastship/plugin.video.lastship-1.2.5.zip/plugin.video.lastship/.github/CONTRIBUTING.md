 *Everybodies help and hints are appreciated.* Please follow the **contribution guidelines** whereever it's possible (and useful).   
### Thank you !
<br />

 *Wir freuen uns über jedermanns Hilfe und Hinweise.* Wo immer es möglich (und sinnvoll) ist, beachten Sie bitte die **Mitarbeits-Richtlinien**.   
### Vielen Dank ! 
 
-  -  -
<br />

## Contributing / Beteiligung
<br />

### Code contribution / Einreichen von Programmcode

#### To submit new code or suggest changes, please [fork](https://help.github.com/articles/fork-a-repo/) this GitHub repository and submit a [Pull Request](https://help.github.com/articles/creating-a-pull-request-from-a-fork/) to the "**nightly**" branch   
#### Möchten Sie neuen Code oder Änderungsvorschläge beisteuern, erzeugen Sie bitte einen [Fork](https://help.github.com/articles/fork-a-repo/) dieses GitHub-Repositories und reichen Sie einen [Pull Request](https://help.github.com/articles/creating-a-pull-request-from-a-fork/) zum Branch "**nightly**" ein   

<br />

### Bug and Malfunction Reports / Meldung von Ablauf- und Programmfehlern

#### Please open an [Issue](https://help.github.com/articles/creating-an-issue/), preferably using the template which will be opened automatically.
#### Hierfür öffnen Sie bitte ein [Issue](https://help.github.com/articles/creating-an-issue/) und verwenden Sie möglichst das sich automatisch öffnende Formular.
#### Please provide a **Debug Log**. / Bitte ein **Debug-Log** beifügen. ([How-To](http://kodi.wiki/view/Log_file))

