 *Everybodies help and hints are appreciated.*
 Please follow the **contribution guidelines** where possible.   

 *Wir freuen uns über jedermanns Hilfe und Hinweise.*
 Wo immer möglich, beachten Sie bitte die **Mitarbeits-Richtlinien**   

 Thank you / Vielen Dank !   
 
-  -  -

<br />

## Contributing Code / Code beisteuern

#### To submit new code or suggest changes, please [fork](https://help.github.com/articles/fork-a-repo/) this GitHub repository and submit a [Pull Request](https://help.github.com/articles/creating-a-pull-request-from-a-fork/) to the `nightly` branch   
#### Möchten Sie neuen Code oder Änderungsvorschläge beisteuern, erzeugen Sie bitte einen [Fork](https://help.github.com/articles/fork-a-repo/) dieses GitHub-Repositories und reichen Sie einen [Pull Request](https://help.github.com/articles/creating-a-pull-request-from-a-fork/) zum `Nightly`-Branch ein   

<br />

## Malfunction and Bug Reports / Meldung von Ablauf- und Programmfehlern

#### Please open an [Issue](https://help.github.com/articles/creating-an-issue/) using the template which will be opened automatically
#### Hierfür öffnen Sie bitte ein [Issue](https://help.github.com/articles/creating-an-issue/) und verwenden Sie das sich automatisch öffnende Formular
#### Please provide / Bitte beifügen :
#### [Debug-Log](http://kodi.wiki/view/Log_file)

