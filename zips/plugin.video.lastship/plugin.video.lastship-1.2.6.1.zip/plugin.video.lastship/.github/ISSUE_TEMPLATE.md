## Expected Behavior / Erwartetes Verhalten :



## Actual Behavior / Tatsächliches Verhalten :



### Steps to Reproduce / Schritte zur Reproduktion :



### Additional Information / Weitere Informationen :


#### Hardware, Kodi Version, Lastship Version :

#### Environment (additional Hardware, OS, ...) / Umgebung (zusätzl. Hardware, Betriebssystem, ...) :

##### Network Setup / Netzwerk-Konfiguration :

### **(Link to / Link zum) Debug-Logfile** :


